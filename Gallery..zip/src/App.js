import React from 'react';
import Button from './Button';
import logo from './logo.svg';
import Gallery from './Gallery';
class App extends React.Component{
  constructor(props){
    super(props)
    this.state={
      Image:""
    }
  }
  getData=(val)=>{
    this.setState({Image:val})
  }
  render(){
    return(
      <div className="App">
      <Button sntData={this.getData}/>
      <Gallery get={this.state.Image}/>
    </div>
    )
  }
}
export default App;
