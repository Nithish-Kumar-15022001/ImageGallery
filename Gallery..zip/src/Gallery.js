import React from "react";
import "./Gallery.css"
import tomatoes from "./Veg/tomatoes.jpg"
import mushroom from "./Veg/mushroom.jpg"
import carrot from "./Veg/carrot.jpg"
import broccoli from "./Veg/broccoli.jpg"
import mangoes from "./Fruit/Mangoes.webp"
import marian from "./Fruit/MarianPlum.webp"
import Papaya from "./Fruit/Papaya.webp"
import Peaches from "./Fruit/Peaches.webp"
import almonds from "./Dry/almonds.jpg"
import berries from "./Dry/berries.jpg"
import kishmish from "./Dry/kishmish.jpg"
import walnut from "./Dry/walnut.jpg"
class Gallery extends React.Component {
    vegobj = [{img:tomatoes,category:"all veg",head:"Tomatoe"}, {img:mushroom,category:"all veg",head:"Mushroom"}, {img:carrot,category:"all veg",head:"Carrot"}, {img:broccoli,category:"all veg",head:"Broccoli"}]
    fruitobj = [{img:mangoes,category:"all fruit",head:"Mangoes"}, {img:marian,category:"all fruit",head:"MarianPlum"},{img:Papaya,category:"all fruit",head:"Papaya"}, {img:Peaches,category:"all fruit",head:"Peaches"}]
    drytobj = [{img:almonds,category:"all dry",head:"Almonds"},{img:berries,category:"all dry",head:"Berries"},{img:kishmish,category:"all dry",head:"Kishmish"},{img:walnut,category:"all dry",head:"Walnut"}]
    constructor(props){
        super(props)
    }
    render() {
        let showveg = this.vegobj.map((val) => {
            if(val.category.includes(this.props.get)){
                return (
                    <div className="veg">
                        <h2>{val.head}</h2>
                        <img src={val.img} alt="image" />
                    </div>
                ) 
            }
            else{
                
            }
                      
        })
        let showfruit = this.fruitobj.map((val) => {
        if(val.category.includes(this.props.get)){
            return (
                <div className="fruit">
                    <h2>{val.head}</h2>
                    <img src={val.img} alt="image" />
                </div>
            )
      
        }
        })
        let showdry = this.drytobj.map((val) => {
            if(val.category.includes(this.props.get)){
                return (
                    <div className="dry">
                        <h2>{val.head}</h2>
                        <img src={val.img} alt="image" />
                    </div>
                )
            }
          
        })
        return (
            <div>
                 {/* {this.props.get} */}
                <div className="heading"><h2>Vegetables</h2></div>
                <div className="sveg">
                    {showveg}
                </div>
                <div className="heading"><h2>Fruit</h2></div>
                <div className="sfruit">
                    {showfruit}
                </div>
                <div className="heading"><h2>Dry</h2></div>
                <div className="sdry">
                    {showdry}
                </div>
            </div>
        )
    }
}
export default Gallery;