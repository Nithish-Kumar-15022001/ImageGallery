import React from "react";
class Button extends React.Component{
  btnobj=[{btn:"vegetables",category:"veg"},{btn:"fruits",category:"fruit"},{btn:"dryFruits",category:"dry"},{btn:"all",category:"all"}]
  handelclick=(val)=>{
    // console.log(val)
    this.props.sntData(val)
  }
  render(){
   let showbtn=this.btnobj.map((val)=>{
      return(
        <div>
          <button onClick={()=>{this.handelclick(val.category)}}>{val.btn}</button>
        </div>
      )
    });
    return(
        <div className="buttons">
          {showbtn}
        </div>
    )
  }
}
export default Button;